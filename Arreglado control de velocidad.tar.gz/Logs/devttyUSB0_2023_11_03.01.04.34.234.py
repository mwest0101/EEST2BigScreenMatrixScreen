���
 
sizeParams=2
[0]=a:efe2;v:1;r:2 [1]=m:AB 
----------------------------------------------------------------
vecStr Antes de entrar
[0]=a:efe2;v:1;r:2 [1]=m:AB 
----------------------------------------------------------------
globalVelocity=5
difTime=300000 calcLoopTime=300000
passBt=0
contRepeat=0 repeat=1
Entro por tiempo=0
--->(2)-----------
c=0 
o=[a] e=[efe2] t=[] v=[1] r=[2] gv=[5] gs=[play] 
--->(2B)-----------
--->(4B)-----------
->efe2
this->contFrame=0
0 0 0 1 0 0 0 
0 0 0 1 0 0 0 
0 1 1 1 1 1 0 
0 0 0 1 0 0 0 
0 0 0 1 0 0 0 
 
--->(5)-----------
 
 
 
 
--->(8)-----------
contParam=0 sizeParams=2
contRepeat=0 repeat=2
----------------------------------------------------------------
vecStr Antes de entrar
[0]=a:efe2;v:1;r:2 [1]=m:AB 
----------------------------------------------------------------
globalVelocity=5
difTime=0 calcLoopTime=300000
passBt=0
----------------------------------------------------------------
vecStr Antes de entrar
[0]=a:efe2;v:1;r:2 [1]=m:AB 
----------------------------------------------------------------
globalVelocity=5
difTime=627896 calcLoopTime=300000
passBt=0
contRepeat=0 repeat=2
Entro por tiempo=0
--->(4B)-----------
->efe2
this->contFrame=40
0 0 1 0 0 0 0 
0 0 0 1 0 1 0 
0 0 1 1 1 0 0 
0 1 0 1 0 0 0 
0 0 0 0 1 0 0 
 
--->(5)-----------
 
 
 
 
--->(8)-----------
contParam=0 sizeParams=2
contRepeat=0 repeat=2
----------------------------------------------------------------
vecStr Antes de entrar
[0]=a:efe2;v:1;r:2 [1]=m:AB 
----------------------------------------------------------------
globalVelocity=5
difTime=0 calcLoopTime=300000
passBt=0
----------------------------------------------------------------
vecStr Antes de entrar
[0]=a:efe2;v:1;r:2 [1]=m:AB 
----------------------------------------------------------------
globalVelocity=5
difTime=547040 calcLoopTime=300000
passBt=0
contRepeat=0 repeat=2
Entro por tiempo=0
--->(4B)-----------
->efe2
this->contFrame=80
0 1 0 0 0 1 0 
0 0 1 0 1 0 0 
0 0 0 1 0 0 0 
0 0 1 0 1 0 0 
0 1 0 0 0 1 0 
 
--->(5)-----------
 
 
 
 
--->(8)-----------
contParam=0 sizeParams=2
contRepeat=0 repeat=2
----------------------------------------------------------------
vecStr Antes de entrar
[0]=a:efe2;v:1;r:2 [1]=m:AB 
----------------------------------------------------------------
globalVelocity=5
difTime=0 calcLoopTime=300000
passBt=0
----------------------------------------------------------------
vecStr Antes de entrar
[0]=a:efe2;v:1;r:2 [1]=m:AB 
----------------------------------------------------------------
globalVelocity=5
difTime=547040 calcLoopTime=300000
passBt=0
contRepeat=0 repeat=2
Entro por tiempo=0
--->(4B)-----------
->efe2
this->contFrame=120
0 0 0 0 1 0 0 
0 1 0 1 0 0 0 
0 0 1 1 1 0 0 
0 0 0 1 0 1 0 
0 0 1 0 0 0 0 
 
--->(5)-----------
 
 
 
 
--->(7)----------
Reset : contFrame=0
setIfIsStringEnd=1
--->(8)-----------
contParam=0 sizeParams=2
contRepeat=1 repeat=2
----------------------------------------------------------------
vecStr Antes de entrar
[0]=a:efe2;v:1;r:2 [1]=m:AB 
----------------------------------------------------------------
globalVelocity=5
difTime=0 calcLoopTime=300000
passBt=0
----------------------------------------------------------------
vecStr Antes de entrar
[0]=a:efe2;v:1;r:2 [1]=m:AB 
----------------------------------------------------------------
globalVelocity=5
difTime=610480 calcLoopTime=300000
passBt=0
contRepeat=1 repeat=2
Entro por tiempo=0
--->(2)-----------
c=0 
o=[a] e=[efe2] t=[] v=[1] r=[2] gv=[5] gs=[play] 
--->(2B)-----------
--->(4B)-----------
->efe2
this->contFrame=0
0 0 0 1 0 0 0 
0 0 0 1 0 0 0 
0 1 1 1 1 1 0 
0 0 0 1 0 0 0 
0 0 0 1 0 0 0 
 
--->(5)-----------
 
 
 
 
--->(8)-----------
contParam=0 sizeParams=2
contRepeat=1 repeat=2
----------------------------------------------------------------
vecStr Antes de entrar
[0]=a:efe2;v:1;r:2 [1]=m:AB 
----------------------------------------------------------------
globalVelocity=5
difTime=0 calcLoopTime=300000
passBt=0
----------------------------------------------------------------
vecStr Antes de entrar
[0]=a:efe2;v:1;r:2 [1]=m:AB 
----------------------------------------------------------------
globalVelocity=5
difTime=647920 calcLoopTime=300000
passBt=0
contRepeat=1 repeat=2
Entro por tiempo=0
--->(4B)-----------
->efe2
this->contFrame=40
0 0 1 0 0 0 0 
0 0 0 1 0 1 0 
0 0 1 1 1 0 0 
0 1 0 1 0 0 0 
0 0 0 0 1 0 0 
 
--->(5)-----------
 
 
 
 
--->(8)-----------
contParam=0 sizeParams=2
contRepeat=1 repeat=2
----------------------------------------------------------------
vecStr Antes de entrar
[0]=a:efe2;v:1;r:2 [1]=m:AB 
----------------------------------------------------------------
globalVelocity=5
difTime=0 calcLoopTime=300000
passBt=0
----------------------------------------------------------------
vecStr Antes de entrar
[0]=a:efe2;v:1;r:2 [1]=m:AB 
----------------------------------------------------------------
globalVelocity=5
difTime=547040 calcLoopTime=300000
passBt=0
contRepeat=1 repeat=2
Entro por tiempo=0
--->(4B)-----------
->efe2
this->contFrame=80
0 1 0 0 0 1 0 
0 0 1 0 1 0 0 
0 0 0 1 0 0 0 
0 0 1 0 1 0 0 
0 1 0 0 0 1 0 
 
--->(5)-----------
 
 
 
 
--->(8)-----------
contParam=0 sizeParams=2
contRepeat=1 repeat=2
----------------------------------------------------------------
vecStr Antes de entrar
[0]=a:efe2;v:1;r:2 [1]=m:AB 
----------------------------------------------------------------
globalVelocity=5
difTime=0 calcLoopTime=300000
passBt=0
----------------------------------------------------------------
vecStr Antes de entrar
[0]=a:efe2;v:1;r:2 [1]=m:AB 
----------------------------------------------------------------
globalVelocity=5
difTime=547040 calcLoopTime=300000
passBt=0
contRepeat=1 repeat=2
Entro por tiempo=0
--->(4B)-----------
->efe2
this->contFrame=120
0 0 0 0 1 0 0 
0 1 0 1 0 0 0 
0 0 1 1 1 0 0 
0 0 0 1 0 1 0 
0 0 1 0 0 0 0 
 
--->(5)-----------
 
 
 
 
--->(7)----------
Reset : contFrame=0
setIfIsStringEnd=1
--->(8)-----------
contParam=0 sizeParams=2
contRepeat=2 repeat=2
--->(9)-----------
contRepeat=0 contParam=1
----------------------------------------------------------------
vecStr Antes de entrar
[0]=a:efe2;v:1;r:2 [1]=m:AB 
----------------------------------------------------------------
globalVelocity=5
difTime=0 calcLoopTime=300000
passBt=0
----------------------------------------------------------------
vecStr Antes de entrar
[0]=a:efe2;v:1;r:2 [1]=m:AB 
----------------------------------------------------------------
globalVelocity=5
difTime=658324 calcLoopTime=300000
passBt=0
contRepeat=0 repeat=2
Entro por tiempo=1
--->(2)-----------
c=1 
o=[m] e=[] t=[AB] v=[5] r=[1] gv=[5] gs=[play] 
--->(2A)-----------
Cambio el string
setIfIsStringEnd=0
--->(3)-----------
contCharAdded=0

getCharMatrix | Letter=:65  
 
Letter=A
----------------------------------------------------------------
AddConsToMatrix
0|1|0|0|||8
1|0|1|0|||8
1|1|1|0|||8
1|0|1|0|||8
1|0|1|0|||9
this->totPosX:7 
 
setCanAddChar=0
--->(4)-----------
============================================================
this->rows:5 this->cols:21
 
===== 0| 1| 2| 3| 4| 5| 6| 7| 8| 9|10|11|12|13|14|15|16|17|18|19|20|
---------------------------------------------------------------
 0 =  0| 0| 0| 0| 0| 0| 0| 0| 1| 0| 0| 0| 0| 0| 0| 0| 0| 0| 0| 0| 0|
 1 =  0| 0| 0| 0| 0| 0| 0| 1| 0| 1| 0| 0| 0| 0| 0| 0| 0| 0| 0| 0| 0|
 2 =  0| 0| 0| 0| 0| 0| 0| 1| 1| 1| 0| 0| 0| 0| 0| 0| 0| 0| 0| 0| 0|
 3 =  0| 0| 0| 0| 0| 0| 0| 1| 0| 1| 0| 0| 0| 0| 0| 0| 0| 0| 0| 0| 0|
 4 =  0| 0| 0| 0| 0| 0| 0| 1| 0| 1| 0| 0| 0| 0| 0| 0| 0| 0| 0| 0| 0|
--->(4A)-----------
--->(5)-----------
 
 
 
 
--->(8)-----------
contParam=1 sizeParams=2
contRepeat=0 repeat=1
----------------------------------------------------------------
vecStr Antes de entrar
[0]=a:efe2;v:1;r:2 [1]=m:AB 
----------------------------------------------------------------
globalVelocity=5
difTime=0 calcLoopTime=300000
passBt=0
----------------------------------------------------------------
vecStr Antes de entrar
[0]=a:efe2;v:1;r:2 [1]=m:AB 
----------------------------------------------------------------
globalVelocity=5
difTime=1471600 calcLoopTime=300000
passBt=0
contRepeat=0 repeat=1
Entro por tiempo=1
--->(4)-----------
============================================================
this->rows:5 this->cols:21
 
===== 0| 1| 2| 3| 4| 5| 6| 7| 8| 9|10|11|12|13|14|15|16|17|18|19|20|
---------------------------------------------------------------
 0 =  0| 0| 0| 0| 0| 0| 0| 1| 0| 0| 0| 0| 0| 0| 0| 0| 0| 0| 0| 0| 0|
 1 =  0| 0| 0| 0| 0| 0| 1| 0| 1| 0| 0| 0| 0| 0| 0| 0| 0| 0| 0| 0| 0|
 2 =  0| 0| 0| 0| 0| 0| 1| 1| 1| 0| 0| 0| 0| 0| 0| 0| 0| 0| 0| 0| 0|
 3 =  0| 0| 0| 0| 0| 0| 1| 0| 1| 0| 0| 0| 0| 0| 0| 0| 0| 0| 0| 0| 0|
 4 =  0| 0| 0| 0| 0| 0| 1| 0| 1| 0| 0| 0| 0| 0| 0| 0| 0| 0| 0| 0| 0|
--->(4A)-----------
--->(5)-----------
 
 
 
 
--->(8)-----------
contParam=1 sizeParams=2
contRepeat=0 repeat=1
----------------------------------------------------------------
vecStr Antes de entrar
[0]=a:efe2;v:1;r:2 [1]=m:AB 
----------------------------------------------------------------
globalVelocity=5
difTime=0 calcLoopTime=300000
passBt=0
----------------------------------------------------------------
vecStr Antes de entrar
[0]=a:efe2;v:1;r:2 [1]=m:AB 
----------------------------------------------------------------
globalVelocity=5
difTime=1054560 calcLoopTime=300000
passBt=0
contRepeat=0 repeat=1
Entro por tiempo=1
--->(4)-----------
============================================================
this->rows:5 this->cols:21
 
===== 0| 1| 2| 3| 4| 5| 6| 7| 8| 9|10|11|12|13|14|15|16|17|18|19|20|
---------------------------------------------------------------
 0 =  0| 0| 0| 0| 0| 0| 1| 0| 0| 0| 0| 0| 0| 0| 0| 0| 0| 0| 0| 0| 0|
 1 =  0| 0| 0| 0| 0| 1| 0| 1| 0| 0| 0| 0| 0| 0| 0| 0| 0| 0| 0| 0| 0|
 2 =  0| 0| 0| 0| 0| 1| 1| 1| 0| 0| 0| 0| 0| 0| 0| 0| 0| 0| 0| 0| 0|
 3 =  0| 0| 0| 0| 0| 1| 0| 1| 0| 0| 0| 0| 0| 0| 0| 0| 0| 0| 0| 0| 0|
 4 =  0| 0| 0| 0| 0| 1| 0| 1| 0| 0| 0| 0| 0| 0| 0| 0| 0| 0| 0| 0| 0|
--->(4A)-----------
--->(5)-----------
 
 
 
 
--->(8)-----------
contParam=1 sizeParams=2
contRepeat=0 repeat=1
----------------------------------------------------------------
vecStr Antes de entrar
[0]=a:efe2;v:1;r:2 [1]=m:AB 
----------------------------------------------------------------
globalVelocity=5
difTime=0 calcLoopTime=300000
passBt=0
----------------------------------------------------------------
vecStr Antes de entrar
[0]=a:efe2;v:1;r:2 [1]=m:AB 
----------------------------------------------------------------
globalVelocity=5
difTime=1054560 calcLoopTime=300000
passBt=0
contRepeat=0 repeat=1
Entro por tiempo=1
--->(4)-----------
============================================================
this->rows:5 this->cols:21
 
===== 0| 1| 2| 3| 4| 5| 6| 7| 8| 9|10|11|12|13|14|15|16|17|18|19|20|
---------------------------------------------------------------
 0 =  0| 0| 0| 0| 0| 1| 0| 0| 0| 0| 0| 0| 0| 0| 0| 0| 0| 0| 0| 0| 0|
 1 =  0| 0| 0| 0| 1| 0| 1| 0| 0| 0| 0| 0| 0| 0| 0| 0| 0| 0| 0| 0| 0|
 2 =  0| 0| 0| 0| 1| 1| 1| 0| 0| 0| 0| 0| 0| 0| 0| 0| 0| 0| 0| 0| 0|
 3 =  0| 0| 0| 0| 1| 0| 1| 0| 0| 0| 0| 0| 0| 0| 0| 0| 0| 0| 0| 0| 0|
 4 =  0| 0| 0| 0| 1| 0| 1| 0| 0| 0| 0| 0| 0| 0| 0| 0| 0| 0| 0| 0| 0|
--->(4A)-----------
--->(5)-----------
 
 
 
 
--->(8)-----------
contParam=1 sizeParams=2
contRepeat=0 repeat=1
----------------------------------------------------------------
vecStr Antes de entrar
[0]=a:efe2;v:1;r:2 [1]=m:AB 
----------------------------------------------------------------
globalVelocity=5
difTime=0 calcLoopTime=300000
passBt=0
----------------------------------------------------------------
vecStr Antes de entrar
[0]=a:efe2;v:1;r:2 [1]=m:AB 
----------------------------------------------------------------
globalVelocity=5
difTime=1054560 calcLoopTime=300000
passBt=0
contRepeat=0 repeat=1
Entro por tiempo=1
--->(4)-----------
============================================================
this->rows:5 this->cols:21
 
===== 0| 1| 2| 3| 4| 5| 6| 7| 8| 9|10|11|12|13|14|15|16|17|18|19|20|
---------------------------------------------------------------
 0 =  0| 0| 0| 0| 1| 0| 0| 0| 0| 0| 0| 0| 0| 0| 0| 0| 0| 0| 0| 0| 0|
 1 =  0| 0| 0| 1| 0| 1| 0| 0| 0| 0| 0| 0| 0| 0| 0| 0| 0| 0| 0| 0| 0|
 2 =  0| 0| 0| 1| 1| 1| 0| 0| 0| 0| 0| 0| 0| 0| 0| 0| 0| 0| 0| 0| 0|
 3 =  0| 0| 0| 1| 0| 1| 0| 0| 0| 0| 0| 0| 0| 0| 0| 0| 0| 0| 0| 0| 0|
 4 =  0| 0| 0| 1| 0| 1| 0| 0| 0| 0| 0| 0| 0| 0| 0| 0| 0| 0| 0| 0| 0|
--->(4A)-----------
setCanAddChar=1
--->(5)-----------
 
 
 
 
--->(8)-----------
contParam=1 sizeParams=2
contRepeat=0 repeat=1
----------------------------------------------------------------
vecStr Antes de entrar
[0]=a:efe2;v:1;r:2 [1]=m:AB 
----------------------------------------------------------------
globalVelocity=5
difTime=0 calcLoopTime=300000
passBt=0
----------------------------------------------------------------
vecStr Antes de entrar
[0]=a:efe2;v:1;r:2 [1]=m:AB 
----------------------------------------------------------------
globalVelocity=5
difTime=1072240 calcLoopTime=300000
passBt=0
contRepeat=0 repeat=1
Entro por tiempo=1
--->(3)-----------
contCharAdded=1

getCharMatrix | Letter=:66  
 
Letter=B
----------------------------------------------------------------
AddConsToMatrix
1|1|0|0|||8
1|0|1|0|||8
1|1|0|0|||8
1|0|1|0|||8
1|1|0|0|||9
this->totPosX:6 
 
setCanAddChar=0
--->(4)-----------
============================================================
this->rows:5 this->cols:21
 
===== 0| 1| 2| 3| 4| 5| 6| 7| 8| 9|10|11|12|13|14|15|16|17|18|19|20|
---------------------------------------------------------------
 0 =  0| 0| 0| 1| 0| 0| 1| 1| 0| 0| 0| 0| 0| 0| 0| 0| 0| 0| 0| 0| 0|
 1 =  0| 0| 1| 0| 1| 0| 1| 0| 1| 0| 0| 0| 0| 0| 0| 0| 0| 0| 0| 0| 0|
 2 =  0| 0| 1| 1| 1| 0| 1| 1| 0| 0| 0| 0| 0| 0| 0| 0| 0| 0| 0| 0| 0|
 3 =  0| 0| 1| 0| 1| 0| 1| 0| 1| 0| 0| 0| 0| 0| 0| 0| 0| 0| 0| 0| 0|
 4 =  0| 0| 1| 0| 1| 0| 1| 1| 0| 0| 0| 0| 0| 0| 0| 0| 0| 0| 0| 0| 0|
--->(4A)-----------
--->(5)-----------
 
 
 
 
--->(8)-----------
contParam=1 sizeParams=2
contRepeat=0 repeat=1
----------------------------------------------------------------
vecStr Antes de entrar
[0]=a:efe2;v:1;r:2 [1]=m:AB 
----------------------------------------------------------------
globalVelocity=5
difTime=0 calcLoopTime=300000
passBt=0
----------------------------------------------------------------
vecStr Antes de entrar
[0]=a:efe2;v:1;r:2 [1]=m:AB 
----------------------------------------------------------------
globalVelocity=5
difTime=1333280 calcLoopTime=300000
passBt=0
contRepeat=0 repeat=1
Entro por tiempo=1
--->(4)-----------
============================================================
this->rows:5 this->cols:21
 
===== 0| 1| 2| 3| 4| 5| 6| 7| 8| 9|10|11|12|13|14|15|16|17|18|19|20|
---------------------------------------------------------------
 0 =  0| 0| 1| 0| 0| 1| 1| 0| 0| 0| 0| 0| 0| 0| 0| 0| 0| 0| 0| 0| 0|
 1 =  0| 1| 0| 1| 0| 1| 0| 1| 0| 0| 0| 0| 0| 0| 0| 0| 0| 0| 0| 0| 0|
 2 =  0| 1| 1| 1| 0| 1| 1| 0| 0| 0| 0| 0| 0| 0| 0| 0| 0| 0| 0| 0| 0|
 3 =  0| 1| 0| 1| 0| 1| 0| 1| 0| 0| 0| 0| 0| 0| 0| 0| 0| 0| 0| 0| 0|
 4 =  0| 1| 0| 1| 0| 1| 1| 0| 0| 0| 0| 0| 0| 0| 0| 0| 0| 0| 0| 0| 0|
--->(4A)-----------
--->(5)-----------
 
 
 
 
--->(8)-----------
contParam=1 sizeParams=2
contRepeat=0 repeat=1
----------------------------------------------------------------
vecStr Antes de entrar
[0]=a:efe2;v:1;r:2 [1]=m:AB 
----------------------------------------------------------------
globalVelocity=5
difTime=0 calcLoopTime=300000
passBt=0
----------------------------------------------------------------
vecStr Antes de entrar
[0]=a:efe2;v:1;r:2 [1]=m:AB 
----------------------------------------------------------------
globalVelocity=5
difTime=1054560 calcLoopTime=300000
passBt=0
contRepeat=0 repeat=1
Entro por tiempo=1
--->(4)-----------
============================================================
this->rows:5 this->cols:21
 
===== 0| 1| 2| 3| 4| 5| 6| 7| 8| 9|10|11|12|13|14|15|16|17|18|19|20|
---------------------------------------------------------------
 0 =  0| 1| 0| 0| 1| 1| 0| 0| 0| 0| 0| 0| 0| 0| 0| 0| 0| 0| 0| 0| 0|
 1 =  1| 0| 1| 0| 1| 0| 1| 0| 0| 0| 0| 0| 0| 0| 0| 0| 0| 0| 0| 0| 0|
 2 =  1| 1| 1| 0| 1| 1| 0| 0| 0| 0| 0| 0| 0| 0| 0| 0| 0| 0| 0| 0| 0|
 3 =  1| 0| 1| 0| 1| 0| 1| 0| 0| 0| 0| 0| 0| 0| 0| 0| 0| 0| 0| 0| 0|
 4 =  1| 0| 1| 0| 1| 1| 0| 0| 0| 0| 0| 0| 0| 0| 0| 0| 0| 0| 0| 0| 0|
--->(4A)-----------
--->(5)-----------
 
 
 
 
--->(8)-----------
contParam=1 sizeParams=2
contRepeat=0 repeat=1
----------------------------------------------------------------
vecStr Antes de entrar
[0]=a:efe2;v:1;r:2 [1]=m:AB 
----------------------------------------------------------------
globalVelocity=5
difTime=0 calcLoopTime=300000
passBt=0
================================================================
Nuevo String: |iv:4
 
o=[iv] e=[] t=[AB] v=[5] r=[1] gv=[4] gs=[play] 
loopWaitTime=60000
globalVelocity=4
calcLoopTime=240000
iv/ip:strBt=|iv:4
----------------------------------------------------------------
vecStr Antes de entrar
[0]=a:efe2;v:1;r:2 [1]=m:AB 
----------------------------------------------------------------
globalVelocity=4
difTime=1054560 calcLoopTime=240000
passBt=0
contRepeat=0 repeat=1
Entro por tiempo=1
--->(8)-----------
contParam=1 sizeParams=2
contRepeat=0 repeat=1
----------------------------------------------------------------
vecStr Antes de entrar
[0]=a:efe2;v:1;r:2 [1]=m:AB 
----------------------------------------------------------------
globalVelocity=4
difTime=0 calcLoopTime=240000
passBt=0
----------------------------------------------------------------
vecStr Antes de entrar
[0]=a:efe2;v:1;r:2 [1]=m:AB 
----------------------------------------------------------------
globalVelocity=4
difTime=604240 calcLoopTime=240000
passBt=0
contRepeat=0 repeat=1
Entro por tiempo=1
--->(8)-----------
contParam=1 sizeParams=2
contRepeat=0 repeat=1
----------------------------------------------------------------
vecStr Antes de entrar
[0]=a:efe2;v:1;r:2 [1]=m:AB 
----------------------------------------------------------------
globalVelocity=4
difTime=0 calcLoopTime=240000
passBt=0
----------------------------------------------------------------
vecStr Antes de entrar
[0]=a:efe2;v:1;r:2 [1]=m:AB 
----------------------------------------------------------------
globalVelocity=4
difTime=376480 calcLoopTime=240000
passBt=0
contRepeat=0 repeat=1
Entro por tiempo=1
--->(8)-----------
contParam=1 sizeParams=2
contRepeat=0 repeat=1
----------------------------------------------------------------
vecStr Antes de entrar
[0]=a:efe2;v:1;r:2 [1]=m:AB 
----------------------------------------------------------------
globalVelocity=4
difTime=0 calcLoopTime=240000
passBt=0
================================================================
Nuevo String: |iv:3
 
o=[iv] e=[] t=[AB] v=[5] r=[1] gv=[3] gs=[play] 
loopWaitTime=60000
globalVelocity=3
calcLoopTime=180000
iv/ip:strBt=|iv:3
----------------------------------------------------------------
vecStr Antes de entrar
[0]=a:efe2;v:1;r:2 [1]=m:AB 
----------------------------------------------------------------
globalVelocity=3
difTime=376480 calcLoopTime=180000
passBt=0
contRepeat=0 repeat=1
Entro por tiempo=1
--->(8)-----------
contParam=1 sizeParams=2
contRepeat=0 repeat=1
----------------------------------------------------------------
vecStr Antes de entrar
[0]=a:efe2;v:1;r:2 [1]=m:AB 
----------------------------------------------------------------
globalVelocity=3
difTime=0 calcLoopTime=180000
passBt=0
----------------------------------------------------------------
vecStr Antes de entrar
[0]=a:efe2;v:1;r:2 [1]=m:AB 
----------------------------------------------------------------
globalVelocity=3
difTime=603200 calcLoopTime=180000
passBt=0
contRepeat=0 repeat=1
Entro por tiempo=1
--->(8)-----------
contParam=1 sizeParams=2
contRepeat=0 repeat=1
----------------------------------------------------------------
vecStr Antes de entrar
[0]=a:efe2;v:1;r:2 [1]=m:AB 
----------------------------------------------------------------
globalVelocity=3
difTime=0 calcLoopTime=180000
passBt=0
----------------------------------------------------------------
vecStr Antes de entrar
[0]=a:efe2;v:1;r:2 [1]=m:AB 
----------------------------------------------------------------
globalVelocity=3
difTime=376480 calcLoopTime=180000
passBt=0
contRepeat=0 repeat=1
Entro por tiempo=1
--->(8)-----------
contParam=1 sizeParams=2
contRepeat=0 repeat=1
----------------------------------------------------------------
vecStr Antes de entrar
[0]=a:efe2;v:1;r:2 [1]=m:AB 
----------------------------------------------------------------
globalVelocity=3
difTime=0 calcLoopTime=180000
passBt=0
----------------------------------------------------------------
vecStr Antes de entrar
[0]=a:efe2;v:1;r:2 [1]=m:AB 
----------------------------------------------------------------
globalVelocity=3
difTime=376472 calcLoopTime=180000
passBt=0
contRepeat=0 repeat=1
Entro por tiempo=1
--->(8)-----------
contParam=1 sizeParams=2
contRepeat=0 repeat=1
----------------------------------------------------------------
vecStr Antes de entrar
[0]=a:efe2;v:1;r:2 [1]=m:AB 
----------------------------------------------------------------
globalVelocity=3
difTime=0 calcLoopTime=180000
passBt=0
----------------------------------------------------------------
vecStr Antes de entrar
[0]=a:efe2;v:1;r:2 [1]=m:AB 
----------------------------------------------------------------
globalVelocity=3
difTime=376480 calcLoopTime=180000
passBt=0
contRepeat=0 repeat=1
Entro por tiempo=1
--->(8)-----------
contParam=1 sizeParams=2
contRepeat=0 repeat=1
----------------------------------------------------------------
vecStr Antes de entrar
[0]=a:efe2;v:1;r:2 [1]=m:AB 
----------------------------------------------------------------
globalVelocity=3
difTime=0 calcLoopTime=180000
passBt=0
----------------------------------------------------------------
vecStr Antes de entrar
[0]=a:efe2;v:1;r:2 [1]=m:AB 
----------------------------------------------------------------
globalVelocity=3
difTime=376480 calcLoopTime=180000
passBt=0
contRepeat=0 repeat=1
Entro por tiempo=1
--->(8)-----------
contParam=1 sizeParams=2
contRepeat=0 repeat=1
----------------------------------------------------------------
vecStr Antes de entrar
[0]=a:efe2;v:1;r:2 [1]=m:AB 
----------------------------------------------------------------
globalVelocity=3
difTime=0 calcLoopTime=180000
passBt=0
----------------------------------------------------------------
vecStr Antes de entrar
[0]=a:efe2;v:1;r:2 [1]=m:AB 
----------------------------------------------------------------
globalVelocity=3
difTime=376480 calcLoopTime=180000
passBt=0
contRepeat=0 repeat=1
Entro por tiempo=1
--->(8)-----------
contParam=1 sizeParams=2
contRepeat=0 repeat=1
----------------------------------------------------------------
vecStr Antes de entrar
[0]=a:efe2;v:1;r:2 [1]=m:AB 
----------------------------------------------------------------
globalVelocity=3
difTime=0 calcLoopTime=180000
passBt=0
----------------------------------------------------------------
vecStr Antes de entrar
[0]=a:efe2;v:1;r:2 [1]=m:AB 
----------------------------------------------------------------
globalVelocity=3
difTime=376480 calcLoopTime=180000
passBt=0
contRepeat=0 repeat=1
Entro por tiempo=1
--->(8)-----------
contParam=1 sizeParams=2
contRepeat=0 repeat=1
----------------------------------------------------------------
vecStr Antes de entrar
[0]=a:efe2;v:1;r:2 [1]=m:AB 
----------------------------------------------------------------
globalVelocity=3
difTime=0 calcLoopTime=180000
passBt=0
----------------------------------------------------------------
vecStr Antes de entrar
[0]=a:efe2;v:1;r:2 [1]=m:AB 
----------------------------------------------------------------
globalVelocity=3
difTime=376480 calcLoopTime=180000
passBt=0
contRepeat=0 repeat=1
Entro por tiempo=1
--->(8)-----------
contParam=1 sizeParams=2
contRepeat=0 repeat=1
----------------------------------------------------------------
vecStr Antes de entrar
[0]=a:efe2;v:1;r:2 [1]=m:AB 
----------------------------------------------------------------
globalVelocity=3
difTime=0 calcLoopTime=180000
passBt=0
================================================================
Nuevo String: |iv:4
 
o=[iv] e=[] t=[AB] v=[5] r=[1] gv=[4] gs=[play] 
loopWaitTime=60000
globalVelocity=4
calcLoopTime=240000
iv/ip:strBt=|iv:4
----------------------------------------------------------------
vecStr Antes de entrar
[0]=a:efe2;v:1;r:2 [1]=m:AB 
----------------------------------------------------------------
globalVelocity=4
difTime=376480 calcLoopTime=240000
passBt=0
contRepeat=0 repeat=1
Entro por tiempo=1
--->(8)-----------
contParam=1 sizeParams=2
contRepeat=0 repeat=1
----------------------------------------------------------------
vecStr Antes de entrar
[0]=a:efe2;v:1;r:2 [1]=m:AB 
----------------------------------------------------------------
globalVelocity=4
difTime=0 calcLoopTime=240000
passBt=0
----------------------------------------------------------------
vecStr Antes de entrar
[0]=a:efe2;v:1;r:2 [1]=m:AB 
----------------------------------------------------------------
globalVelocity=4
difTime=603200 calcLoopTime=240000
passBt=0
contRepeat=0 repeat=1
Entro por tiempo=1
--->(8)-----------
contParam=1 sizeParams=2
contRepeat=0 repeat=1
----------------------------------------------------------------
vecStr Antes de entrar
[0]=a:efe2;v:1;r:2 [1]=m:AB 
----------------------------------------------------------------
globalVelocity=4
difTime=0 calcLoopTime=240000
passBt=0
----------------------------------------------------------------
vecStr Antes de entrar
[0]=a:efe2;v:1;r:2 [1]=m:AB 
----------------------------------------------------------------
globalVelocity=4
difTime=376480 calcLoopTime=240000
passBt=0
contRepeat=0 repeat=1
Entro por tiempo=1
--->(8)-----------
contParam=1 sizeParams=2
contRepeat=0 repeat=1
----------------------------------------------------------------
vecStr Antes de entrar
[0]=a:efe2;v:1;r:2 [1]=m:AB 
----------------------------------------------------------------
globalVelocity=4
difTime=0 calcLoopTime=240000
passBt=0
----------------------------------------------------------------
vecStr Antes de entrar
[0]=a:efe2;v:1;r:2 [1]=m:AB 
----------------------------------------------------------------
globalVelocity=4
difTime=376480 calcLoopTime=240000
passBt=0
contRepeat=0 repeat=1
Entro por tiempo=1
--->(8)-----------
contParam=1 sizeParams=2
contRepeat=0 repeat=1
----------------------------------------------------------------
vecStr Antes de entrar
[0]=a:efe2;v:1;r:2 [1]=m:AB 
----------------------------------------------------------------
globalVelocity=4
difTime=0 calcLoopTime=240000
passBt=0
----------------------------------------------------------------
vecStr Antes de entrar
[0]=a:efe2;v:1;r:2 [1]=m:AB 
----------------------------------------------------------------
globalVelocity=4
difTime=376480 calcLoopTime=240000
passBt=0
contRepeat=0 repeat=1
Entro por tiempo=1
--->(8)-----------
contParam=1 sizeParams=2
contRepeat=0 repeat=1
----------------------------------------------------------------
vecStr Antes de entrar
[0]=a:efe2;v:1;r:2 [1]=m:AB 
----------------------------------------------------------------
globalVelocity=4
difTime=0 calcLoopTime=240000
passBt=0
----------------------------------------------------------------
vecStr Antes de entrar
[0]=a:efe2;v:1;r:2 [1]=m:AB 
----------------------------------------------------------------
globalVelocity=4
difTime=376480 calcLoopTime=240000
passBt=0
contRepeat=0 repeat=1
Entro por tiempo=1
--->(8)-----------
contParam=1 sizeParams=2
contRepeat=0 repeat=1
----------------------------------------------------------------
vecStr Antes de entrar
[0]=a:efe2;v:1;r:2 [1]=m:AB 
----------------------------------------------------------------
globalVelocity=4
difTime=0 calcLoopTime=240000
passBt=0
----------------------------------------------------------------
vecStr Antes de entrar
[0]=a:efe2;v:1;r:2 [1]=m:AB 
----------------------------------------------------------------
globalVelocity=4
difTime=376480 calcLoopTime=240000
passBt=0
contRepeat=0 repeat=1
Entro por tiempo=1
--->(8)-----------
contParam=1 sizeParams=2
contRepeat=0 repeat=1
----------------------------------------------------------------
vecStr Antes de entrar
[0]=a:efe2;v:1;r:2 [1]=m:AB 
----------------------------------------------------------------
globalVelocity=4
difTime=0 calcLoopTime=240000
passBt=0
----------------------------------------------------------------
vecStr Antes de entrar
[0]=a:efe2;v:1;r:2 [1]=m:AB 
----------------------------------------------------------------
globalVelocity=4
difTime=376480 calcLoopTime=240000
passBt=0
contRepeat=0 repeat