﻿#include <Arduino.h>
#include "BigWallMatrix.h"

BigWallMatrix bm;

void setup()
{
    bm=BigWallMatrix();
}
// Secuencia de la matriz
void loop()
{
      //bm.init();
     /* bm.setText("test");
      bm.ifWaitTime();
      bm.nextFrame();*/
      
}