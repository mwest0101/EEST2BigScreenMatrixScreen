
#include <Arduino.h>
#ifndef _INC_INCLUDES_H_
  #define _INC_INCLUDES_H_
  
  #include "inc_config.h"
  #include "inc_config_debugSerial.h"
  #include <stdlib.h>
  #include <stdio.h>
  #include <avr/pgmspace.h>
  #ifdef IS_LCDSCREEN
    #include <MatrizLed.h>
  #endif
  
  //#include <LibPrintf.h>
  #if DEBUG
    #include "avr8-stub.h"
    #include "app_api.h"
  #endif
 
  
  #include "inc_config_pacman.h"
  
  #include "VectorClass.cpp"
  #include "MatrixClass.cpp"
  #include "inc_functions.h"   
  #include "inc_show_matrix.h"
  #include "inc_drive_matrix.h"
  #include "inc_config_letters.h"
 
  //#include "inc_show_matrix.h"
  //#include "inc_drive_matrix.h"
#endif /* _INC_INCLUDES_H_ */
